<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bootstrap Site</title>
  <link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet" media="all">
  <link href="<?php echo base_url('assets/fontawesome/css/all.css'); ?>" rel="stylesheet">
</head>
<body class="font-monospace bg-secondary">

<!-- VERSI MOBILE -->
<div class="d-md-none">
    <div class="container-fluid">
    <div class="card border-dark mt-5 text-center" style="height:200px">
<h1> HALAMAN KASIR HANYA DAPAT DIAKSES MELALUI PC </h1>
<div class="btn btn-sm btn-success text-light mt-3 mx-auto" style="width:100px">KELUAR</div>
    </div>
    </div>
</div>

<!-- VERSI PC -->
<div class="d-none d-md-block">
    <div class="container-fluid">
    <!-- MEMBAGI MENJADI 3 -->
    <div class="row mt-2">
        <!-- BAGIAN KE 1 -->

        <div class="" style="width:200px">
            <div class="card border-dark gap-2" style="height:90vh;">
            <div class="mx-1 my-1 mb-5">
                 <button class="btn btn-primary" style="width:100%" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBackdrop" aria-controls="offcanvasWithBackdrop"><i class="fas fa-chevron-circle-right fa-2x"></i></button>













            </div>
            <div class="mx-1 my-1 mt-5">
                 <a class="btn btn-primary text-start" style="width:100%" href="dashboard"><i class="fas fa-tachometer-alt"><span class="fst-normal font-monospace"> Dashboard</span></i></a>
            </div>
            <div class="mx-1 my-1">
            <a class="btn btn-primary text-start" style="width:100%" href="dashboard"><i class="fas fa-user"><span class="fst-normal font-monospace"> User</span></i></a>
            </div>
            <div class="mx-1 my-1">
            <a class="btn btn-primary text-start" style="width:100%" href="dashboard"><i class="fas fa-history"><span class="fst-normal font-monospace"> Riwayat</span></i></a>
            </div>
            <div class="mx-1 my-1">
            <a class="btn btn-primary text-start" style="width:100%" href="dashboard"><i class="fas fa-caret-square-left"><span class="fst-normal font-monospace"> Logout</span></i></a>
            </div>
            
            </div>
        </div>



<?php $this->load->view($content); ?>



</div>
<div class="card mt-2 text-center fw-bold border-dark">
    <i class="fa fa-copyright my-2" aria-hidden="true"> 2022 Copyright : RESTO </i>
</div>
</div>
</div>
</body>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>



<script>
  const labels = [
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
    '10',
    '11',
    '12',
    '13',
    '14',
    '15',
    '16',
    '17',
    '18',
    '19',
    '20',
    '21',
    '22',
    '23',
    '24',
    '25',
    '26',
    '27',
    '28',
    '29',
    '30',
  ];

  const data = {
    labels: labels,
    datasets: [{
      label: 'Penghasilan Perhari',
      backgroundColor: 'rgb(255, 99, 132)',
      borderColor: 'rgb(255, 99, 132)',
      data: [225000,350000 ,175000 ,420000 ,370000 ,190000 ,650000 ,520000 ,210000 ,320000 ,270000 ,410000 ,420000 ,180000 ,175000 ,250000 ,195000 ,350000 ,175000 ,150000 ,125000 ,465000 ,560000 ,360000 ,185000 ,270000 ,740000 ,340000 ,130000 ,360000 ],
    }]
  };

  const config = {
    type: 'line',
    data: data,
    options: {}
  };

  const myChart = new Chart(
    document.getElementById('myChart'),
    config
  );




// beda
  const labels1 = [
    'Januari',
    'Februari',
    'Maret',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Agustus',
    'September',
    'Oktober',
    'November',
    'Desember',
  ];

  const data1 = {
    labels: labels1,
    datasets: [{
      label: 'Penghasilan Perbulan',
      backgroundColor: 'rgb(255, 99, 132)',
      borderColor: 'rgb(255, 99, 132)',
      data: [10750000 ,17500000 ,12750000 ,8275000 ,9275000 ,14825000 ,10450000 ,12750000 ,13350000 ,11500000 ,8520000 ,14650000 ],
    }]
  };

  const config1 = {
    type: 'bar',
    data: data1,
    options: {}
  };

  const myChart1 = new Chart(
    document.getElementById('myChart1'),
    config1
  );







  //col 1 
  const data2 = {
  labels: [
    'Minuman',
    'Makanan',
    'M.Penutup'
  ],
  
  datasets: [{
    label: 'My First Dataset',
    data: [120000, 345000, 55000],
    backgroundColor: [
      'rgb(255, 99, 132)',
      'rgb(54, 162, 235)',
      'rgb(255, 205, 86)'
    ],
    
    hoverOffset: 4
  }],
  
};
const config2 = {
  type: 'pie',
  data: data2,
  options: {
      plugins:{
    legend: {
    	display: false
    }
}
},
};

  const myChart2 = new Chart(
    document.getElementById('myChart2'),
    config2
  );







  // col 2
  const data3 = {
  labels: [
    'Minuman',
    'Makanan',
    'M.Penutup'
  ],
  
  datasets: [{
    label: 'My First Dataset',
    data: [12600000, 56210000, 5300000],
    backgroundColor: [
      'rgb(255, 99, 132)',
      'rgb(54, 162, 235)',
      'rgb(255, 205, 86)'
    ],
    
    hoverOffset: 4
  }],
  
};
const config3 = {
  type: 'pie',
  data: data3,
  options: {
      plugins:{
    legend: {
    	display: false
    }
}
},
};

  const myChart3 = new Chart(
    document.getElementById('myChart3'),
    config3
  );







  //col 3
  const data4 = {
  labels: [
    'Minuman',
    'Makanan',
    'M.Penutup'
  ],
  
  datasets: [{
    label: 'My First Dataset',
    data: [8, 24, 4],
    backgroundColor: [
      'rgb(255, 99, 132)',
      'rgb(54, 162, 235)',
      'rgb(255, 205, 86)'
    ],
    
    hoverOffset: 4
  }],
  
};
const config4 = {
  type: 'pie',
  data: data4,
  options: {
      plugins:{
    legend: {
    	display: false
    }
}
},
};

  const myChart4 = new Chart(
    document.getElementById('myChart4'),
    config4
  );




  //col 4
  const data5 = {
  labels: [
    'Minuman',
    'Makanan',
    'M.Penutup'
  ],
  
  datasets: [{
    label: 'My First Dataset',
    data: [580, 1720, 479],
    backgroundColor: [
      'rgb(255, 99, 132)',
      'rgb(54, 162, 235)',
      'rgb(255, 205, 86)'
    ],
    
    hoverOffset: 4
  }],
  
};
const config5 = {
  type: 'pie',
  data: data2,
  options: {
      plugins:{
    legend: {
    	display: false
    }
}
},
};

  const myChart5 = new Chart(
    document.getElementById('myChart5'),
    config5
  );
</script>

</html>



<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasWithBackdrop" aria-labelledby="offcanvasWithBackdropLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasWithBackdropLabel">Offcanvas with backdrop</h5>
    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <p>.....</p>
  </div>
</div>