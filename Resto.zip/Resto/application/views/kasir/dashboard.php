<div class="col">
    <div class="card" style="height:100%">

    <div class="container-fluid">
    <div class="row">
        <div class="col-12">
        <div class="card mt-1 text-center fw-bold bg-primary border-dark text-light"> DASHBOARD</div>
    </div>
    </div>
     

    
        <div class="row">

        <div class="col-3">
                <div class="card  my-1 border-dark" style="height:200px">
<div class="card-header bg-primary fw-bold text-center text-light">
Penghasilan Hari Ini
</div>
<div class="card-body mx-auto" style="width:60%">
<canvas id="myChart2"></canvas>
</div>

                </div>
            </div>

            <div class="col-3">
                <div class="card  my-1 border-dark" style="height:200px">
<div class="card-header bg-primary fw-bold text-center text-light">
Total Penghasilan
</div>
<div class="card-body mx-auto" style="width:60%">
<canvas id="myChart3"></canvas>
</div>

                </div>
            </div>

<div class="col-3">
    <div class="card  my-1 border-dark" style="height:200px">
<div class="card-header bg-primary fw-bold text-center text-light">
Penjualan Hari Ini
</div>
<div class="card-body mx-auto" style="width:60%">
<canvas id="myChart4"></canvas>
</div>

    </div>
</div>

<div class="col-3">
    <div class="card my-1 border-dark" style="height:200px">
<div class="card-header bg-primary fw-bold text-center text-light">
Total penjualan
</div>
<div class="card-body mx-auto" style="width:60%">
<canvas id="myChart5"></canvas>
</div>

    </div>
</div>
        </div>






        <div class="row">
            <div class="col-6">
                <div class="card my-1 border-dark" style="height:300px">
<div class="card-header bg-primary fw-bold text-center text-light">
Penghasilan Tiap Hari
</div>
<div class="card-body mx-auto" style="width:500px">
<canvas id="myChart"></canvas>
</div>

                </div>
            </div>

            <div class="col-6">
                <div class="card my-1 border-dark" style="height:300px">
<div class="card-header bg-primary fw-bold text-center text-light">
Penghasilan Tiap Bulan
</div>
<div class="card-body mx-auto" style="width:500px">
<canvas id="myChart1"></canvas>
</div>

                </div>
            </div>
        </div>
    </div>
    </div>
</div>













