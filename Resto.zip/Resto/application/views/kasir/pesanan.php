
        <!-- BAGIAN KE 2 -->
        <div class="col">
            <div class="card" style="height:100%">
            <div class="card-body">
            <ul class="nav nav-pills mb-3 nav-tabs" id="pills-tab" role="tablist">
  <li class="nav-item col-4 d-flex text-center" role="presentation">
    <button class="nav-link col-12 active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Makanan</button>
  </li>
  <li class="nav-item col-4 d-flex text-center" role="presentation">
    <button class="nav-link col-12" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Minuman</button>
  </li>
  <li class="nav-item col-4 d-flex text-center" role="presentation">
    <button class="nav-link col-12" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">M. Penutup</button>
  </li>
</ul>
<div class="tab-content overflow-auto" id="pills-tabContent" style="height:72vh">







<!-- TAB MAKANAN -->
  <div class="overflow-auto tab-pane fade show active container-fluid" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
<div class="row g-0">

    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Bakar</div>

      <img src="<?php echo base_url('assets/image/ayam-bakar2.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  
  </div>




    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Bakar</div>

      <img src="<?php echo base_url('assets/image/ayam-bakar2.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Sate Ayam</div>

      <img src="<?php echo base_url('assets/image/sate-ayam.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Bakar</div>

      <img src="<?php echo base_url('assets/image/ayam-bakar2.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Bakar</div>

      <img src="<?php echo base_url('assets/image/ayam-bakar2.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Bakar</div>

      <img src="<?php echo base_url('assets/image/ayam-bakar2.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Sop Ayam</div>

      <img src="<?php echo base_url('assets/image/sop-ayam.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Guling</div>

      <img src="<?php echo base_url('assets/image/ayam-guling.png'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Bakar</div>

      <img src="<?php echo base_url('assets/image/ayam-bakar2.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Bakar</div>

      <img src="<?php echo base_url('assets/image/ayam-bakar2.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Rendang Ayam</div>

      <img src="<?php echo base_url('assets/image/rendang-ayam.png'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Goreng</div>

      <img src="<?php echo base_url('assets/image/ayam-goreng.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Bakar</div>

      <img src="<?php echo base_url('assets/image/ayam-bakar2.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Bakar</div>

      <img src="<?php echo base_url('assets/image/ayam-bakar2.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Bakar</div>

      <img src="<?php echo base_url('assets/image/ayam-bakar2.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Bakar</div>

      <img src="<?php echo base_url('assets/image/ayam-bakar2.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Bakar</div>

      <img src="<?php echo base_url('assets/image/ayam-bakar2.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Bakar</div>

      <img src="<?php echo base_url('assets/image/ayam-bakar2.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Bakar</div>

      <img src="<?php echo base_url('assets/image/ayam-bakar2.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
    <div class="card mx-auto mb-1 mx-1 border-dark" style="height:166px; width:170px">
    <div class="card-header bg-primary fw-bold text-center text-light">Ayam Bakar</div>

      <img src="<?php echo base_url('assets/image/ayam-bakar2.jpg'); ?>" alt="" style="width:100%">

  <div class="card-footer">Rp 100.000 <a href="" class="btn btn-sm btn-primary fas fa-shopping-cart"></a></div>  

</div>
  </div>
  </div>







  <div class="overflow-auto tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">tab 2</div>










  <div class="overflow-auto tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">tab 3</div>

</div>
            </div>
          </div>
        </div>



























        <!-- BAGIAN KE 3 -->
        <div class="d-none d-lg-block" style="width:400px">
            <div class="card" style="height:100%">
            <div class="card-body" style="height:100%">
                <p class="text-center"> PESANAN </p>
                
                <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama</th>
      <th scope="col">value</th>
      <th scope="col">Total</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Ayam Bakar</td>
      <td><input type="number" style="width:50px" ></td>
      <td>100.000</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Sate Ayam</td>
      <td><input type="number" style="width:50px" ></td>
      <td>100.000</td>
    </tr>
  </tbody>
</table>
      
            </div>
<div class="card-body">
<table class="table">
  <tbody>
    <tr>
      <td>TOTAL :</td>
      <td style="text-end">200000</td>
    </tr>
    <tr>
      <td>BAYAR :</td>
      <td><input class="border-0 border-bottom border-dark" type="number"></td>
    </tr> 
  </tbody>
</table>
<button class="btn btn-sm btn-primary col-12 text-light">BAYAR</button>
</div>

        </div>
    </div>

