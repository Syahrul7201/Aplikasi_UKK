<div class="container">
  <div class="col-md-8 mx-auto">
    <div class="card mt-5 border-dark"> 
      <div class="row">
        <div class="col-6 d-none d-md-block">
          <div class="card border-0" style="height:75vh">
            <div class="d-flex justify-content-center overflow-hidden" style="width:100%">
            <img src="https://wallpaperaccess.com/full/896261.jpg">
            </div> 
          </div> 
        </div>
        <div class="col">
          <div class="card-body border-0 my-auto" style="height:100%;">
            <p class="mb-4 mt-5 text-center"> LOGIN </p>
            <label for="inputPassword5" class="form-label mt-5 fw-bold">Username</label>
            <input type="text" id="inputPassword5" class="form-control border-0 border-dark border-bottom rounded-0" aria-describedby="passwordHelpBlock" placeholder="Username">
            <label for="inputPassword5" class="form-label mt-3">Password</label>
            <input type="password" id="inputPassword5" class="form-control border-0 border-dark border-bottom rounded-0" aria-describedby="passwordHelpBlock" placeholder="Password">
            <div class="card mt-5">
              <button type="button" class="btn btn-outline-info btn-sm">LOGIN</button>
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>
  </div>
</div>