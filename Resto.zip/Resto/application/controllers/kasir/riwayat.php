<?php
class Riwayat extends CI_Controller {

        public function index()
        {
            $data['content'] = 'kasir/riwayat';
            $this->load->view('kasir/template',$data);
        }
}
