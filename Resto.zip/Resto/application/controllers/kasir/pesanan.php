<?php
class Pesanan extends CI_Controller {

        public function index()
        {
            $data['content'] = 'kasir/pesanan';
            $this->load->view('kasir/template',$data);
        }
}
