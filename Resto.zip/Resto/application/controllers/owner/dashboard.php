<?php
class Dashboard extends CI_Controller {

        public function index()
        {
            $data['content'] = 'kasir/dashboard';
            $this->load->view('owner/template',$data);
        }
}